#include <solver_cplex.h>
#include <math.h>

#define MAXBIDPERJOB 500
#define MAXJOBNODE 51200000

#define MAXCLASSESPERJOB 5000
#define MAXCLASSES 1000000
#define MAXINTERVALS 100000

#define NONCONTIGLEVEL 100


#define LARGENUMBER 10000000
#define MINPREF -4.0

int classCtr, classMapCtr, jobNodeCtr, intervalCtr;
int maxBids;

static void free_and_null (char **ptr);

extern char* get_cplex_license_address(void);

int bidCtr;
int max_gpu;

uint32_t minPrioDiff;

typedef struct bid_t {
	int class;
	int jobIdx;
	int amount;
	int numNodes;
	int firstNode;
	int lastNode;
	int gpu;
	uint32_t priority;
	double preference;
} bid;

typedef struct class_map_t {
	int nodes;
	int cpus;
	int gpus;
	int begin;
	int end;
} class_map;

typedef struct interval_t {
	int begin;
	int end;
	int size;
	int numnodes;
	//QQint *nodes;
	bool whole;
	int gpu;
	int level;
} interval;

typedef struct class_t {
	int numCores;
	int numNodes;
	int numGpus;
	int *nodesUsed;
	double preference;
	/* sil */
	struct class_bidding_job_t *bidding_job;
	int gpn;
	int cpn;
	int amount;
	int sumBids;
	bool isAligned;
} class;

/* holds the LAST element's index for a specific CPN/GPN class exists */
int *cidxArray;
/* same for class union list */
int *cuidxArray;
/* same for class-node list */
int *nidxArray;
int *nArray; 

/* aucsched 2 addition */
int *T;
sched_nodeinfo_t* node_array;
solver_job_list_t* job_array;
int nodeSize;
int windowSize;

/* aucsched 2 addition */
extern int gres_job_gpu_set(List job_gres_list, int gpu);


double alpha;

int *jobNodeIdx, *jobNodeName;
class_map *classMap;
interval *intervals;
int *nodesetCount;
int *cumsum;

class *cArray;
class *cuArray;

bid *bids;

//slurmBids
char *avail_nodelist, *nodelist;
sched_nodeinfo_t* temp_node_array;

//solver_job_list_t *job_array;
//sched_nodeinfo_t *node_array;

/* generate bid for a specific job and class */

/* new tree addition */
int maxLevel;


/*
double preferenceCalculation(int numNodes, int numNodesets, int nodesetSize, 
				double c1, double c2, double c3, int g, int gmax) {
        double c4 = 0.001;
        double ret = 1.0 + c4;
	ret -= (c4 * (gmax + 1) / (g + 1));
        debug4("c4: %.4f g: %d gmax: %d, current ret: %.4f", c4, g, gmax, ret);
        ret -= (c1 + c2 * numNodes / (1 + nodeSize) + c3 * numNodesets / (1 + nodesetSize));
        debug4("c1 %.2f c2 %.2f c3 %.2f numNodes %d nodeSize %d numNodesets %d nodesetSize %d, returning %.4f",
                c1, c2, c3, numNodes, nodeSize, numNodesets, nodesetSize, ret);
        return ret;
}
*/

int returnHigherLevel(int int1id, int int2id) 
{
        int i;
        for (i = 0; i < intervalCtr; i++) {
                if ( (intervals[i].begin <= intervals[int1id].begin) && (intervals[i].end >= intervals[int2id].end) )
                        return i;
        }        
        
        return -1;
}

double preferenceCalculation(int numNodes, int level, int int1id, int int2id, int g, int gmax)
{
        if ( (int1id) && (int2id) )
                level = returnHigherLevel(int1id, int2id);
        debug5("in pref calc. level is %d, numlevel is %d", level, maxLevel);
        double ret = +1.0 +(double)(numNodes)/ nodeSize + (double)(level)/maxLevel - (double)(g)/gmax;
        return ret;
}

int newBid(int amount, int jobIdx, int cIdx, uint32_t priority, double preference, int numNodes, int *_nodes, int gpu, int type)
{	
	int coresPerNode = 0, remaining, k;
	bid *bidPtr;
        if (bidCtr < maxBids) {
		bidPtr = &bids[bidCtr];
	        int i, ok = 1;
        	for (i = job_array[jobIdx].firstBid; i < bidCtr; i++) {
	                if (cIdx == bids[i].class) {
	                        debug5("job %d has already a bid on class %d, skipping",
	                                job_array[jobIdx].job_id, cIdx);
                                return 0;
                        }
                }
        	if (ok) {
        	bids[bidCtr].class = cIdx;
        	bids[bidCtr].amount = MIN(amount, job_array[jobIdx].min_cpus);
        	remaining = bids[bidCtr].amount;
        	bids[bidCtr].jobIdx = jobIdx;
        	bids[bidCtr].priority = priority;
        	bids[bidCtr].preference = preference;
        	bids[bidCtr].numNodes = numNodes;
        	bids[bidCtr].firstNode = jobNodeCtr;
		bids[bidCtr].gpu = gpu;

                debug4("creating bid for job %d, class %d, numnodes %d, last of nodes %d, bid id %d, amount %d",
                        jobIdx, cIdx, numNodes, _nodes[numNodes - 1], bidCtr, bids[bidCtr].amount);
                if (job_array[jobIdx].cpus_per_node > 0) {
			coresPerNode = job_array[jobIdx].cpus_per_node;
		}
		
		bidPtr->lastNode = bidPtr->firstNode + numNodes;
		for (i = bidPtr->firstNode; i < bidPtr->lastNode; i++) {
			k = i - bidPtr->firstNode;
			debug5("jobNodeCtr %d",jobNodeCtr);
			debug5("_nodes[k] %d",_nodes[k]);
			debug5("jobNodeIdx[jobNodeCtr] %d", jobNodeIdx[jobNodeCtr]);
			debug5("nArray[_nodes[k]] %d", nArray[_nodes[k]]);

                        jobNodeName[jobNodeCtr] = _nodes[k];
                        jobNodeIdx[jobNodeCtr] = jobNodeCtr;

                        jobNodeCtr++;

                        if (node_array[_nodes[k]].rem_cpus == 0) {
                                T[i] = 0;
                                continue;
                        }

			T[i] = 1;
			remaining--;
                        debug5("job %d bidding on node %d (%d) bid id %d, nArray element %d",jobIdx,_nodes[k],jobNodeName[jobNodeCtr],bidCtr+1,nArray[_nodes[k]]);
                        nArray[_nodes[k]]++;


			if (remaining == 0) {
				debug5("remaining 0");
				bidPtr->lastNode = i + 1;
				bidPtr->numNodes = bidPtr->lastNode - bidPtr->firstNode;
				break;
			}
		}

		debug2("job %d bid on nodes completed moving to core dist", jobIdx);

		if (coresPerNode > 0) {
			for (i = bidPtr->firstNode; i < bidPtr->lastNode; i++) {
        			k = i - bidPtr->firstNode;
                                if (node_array[_nodes[k]].rem_cpus == 0) {
                                        T[i] = 0;
                                        continue;
                                }
				int min_val = MIN(coresPerNode - 1, remaining);
				T[i] += min_val;
				remaining -= min_val;
			}
		} else {
	                /* block distribution */
        	        /* cores per node not enabled */
                        for (i = bidPtr->firstNode; i < bidPtr->lastNode; i++) {
				k = i - bidPtr->firstNode;
                                if (node_array[_nodes[k]].rem_cpus == 0) {
                                        T[i] = 0;
                                        continue;
                                }
                                int min_val = MIN(node_array[_nodes[k]].rem_cpus - 1, remaining);
                                T[i] += min_val;
                                remaining -= min_val;
                                debug5("allocated at node %d %d remaining now %d", k, T[i], remaining);
                                
                        }
		}

        	debug("created bid no %d, class %d, job %d, numNodes %d firstNode %d lastNode %d, prio: %d, pref: %.4f, gpu %d type %d, remaining %d",
                      bidCtr, cIdx, jobIdx, numNodes, bids[bidCtr].firstNode, bids[bidCtr].lastNode, priority, preference, gpu, type, remaining);
                for (i = bidPtr->firstNode; i < bidPtr->lastNode; i++) {
                        k = i - bidPtr->firstNode;
                        debug5("allocation of bid %d at node %d is %d",
                                bidCtr, k, T[i]);
                }
                bidCtr++;
        	if (jobNodeCtr >= MAXJOBNODE)
	              maxBids = bidCtr;
	        }
	        cArray[cIdx].preference = MINPREF;
	        return 1;
        } else {
                return -1;
        }
}

void cumSumGeneration()
{
	int g, i, j, k;
	for (i = 0; i < nodeSize; i++) {
		if (node_array[i].rem_gpus > max_gpu)
			max_gpu = node_array[i].rem_gpus;
	}
	
	nodesetCount = (int *)malloc((max_gpu + 1) * sizeof(int));
	cumsum = (int *)malloc((1 + nodeSize) * (1 + max_gpu) * sizeof(int));
	debug("cumsum created. max_gpu: %d", max_gpu);
	
	intervalCtr = 0;
	for (g = max_gpu; g >= 0; g--) {
	        nodesetCount[g] = 0;
	        cumsum[g * (nodeSize + 1)] = 0;
		for (i = 1; i <= nodeSize; i++) {
			if (node_array[i - 1].rem_gpus >= g)
				cumsum[g * (nodeSize + 1) + i] = cumsum[g * (nodeSize + 1) + i - 1] + node_array[i - 1].rem_cpus;
			else
				cumsum[g * (nodeSize + 1) + i] = cumsum[g * (nodeSize + 1) + i - 1];
				
		}
		debug2("last element of cumsum with gpu %d is %d",g,cumsum[(g + 1) * (nodeSize + 1) - 1]);
		
		
		// NO SWITCHES
		//goto switches;
		/*
		k = g * (nodeSize + 1); // k is starting point
		while (k < (g + 1) * (nodeSize + 1)) {
		        // find the beginning point 'k' of interval, where 'k+1' has higher cumsum then k.
                        if ( (k <= (g + 1) * (nodeSize + 1)) && (cumsum[k + 1] - cumsum[k] == 0) ) {
                                k++;
                                continue;
                        }
			// find the ending point 'i' of interval, where 'i+1' has equal cumsum to 'i'
	 		for (i = k; i < (g + 1) * (nodeSize + 1); i++) {
                        	if ( (cumsum[i + 1] - cumsum[i] <= 0) || 
                        	     ( (i + 1 == (g + 1) * (nodeSize + 1)) && (cumsum[i] - cumsum[i - 1] > 0 ) ) ) {
                        	        intervals[intervalCtr].begin = k - g * (nodeSize + 1);
                                	intervals[intervalCtr].end = i - g * (nodeSize + 1) - 1;
					if (intervals[intervalCtr].end < intervals[intervalCtr].begin)
						continue;
                                	intervals[intervalCtr].numnodes = i - k;
					//intervals[intervalCtr].nodes = (int *)malloc(intervals[intervalCtr].numnodes * sizeof(int));
					//for (p = 0; p < intervals[intervalCtr].numnodes; p++) {
						//intervals[intervalCtr].nodes[p] = intervals[intervalCtr].begin + p;
					        //debug3("interval %d node %d: %d",intervalCtr,p,intervals[intervalCtr].nodes[p]);
                                        //}
                                	intervals[intervalCtr].size = cumsum[i] - cumsum[k];
                                	intervals[intervalCtr].gpu = g;
                                	debug5("new interval 1, intervalCtr %d, begin %d , end %d",
                                                intervalCtr, intervals[intervalCtr].begin, intervals[intervalCtr].end);
                                	k = i + 1; 
                                	intervalCtr++;
                                	nodesetCount[g]++;
                                	break;
                        	}
	 		}
	 		k++;
        	}
        	*/
        	
        	// SWITCHES
        	for (j = 0; j < switch_record_cnt; j++) {
        	        int first = bit_ffs(switch_record_table[j].node_bitmap);
        	        int last = bit_fls(switch_record_table[j].node_bitmap);
        	        
        	        //debug("switch %d first %d last %d", j, first, last);
        	        
        	        //first, add whole switch
                        interval* intptr = &intervals[intervalCtr];
                        intptr->begin = first;
                        intptr->end = last;
                        intptr->numnodes = last - first + 1;
                        intptr->size = cumsum[last + 1] - cumsum[first];
                        intptr->gpu = g;
                        intptr->level = switch_record_table[j].level;
                        debug3("new interval %d, begin %d, end %d, size %d, level %d (whole switch)",
                                intervalCtr, intptr->begin, intptr->end, intptr->size, intptr->level);
                        intervalCtr++;
                        nodesetCount[g]++;
        	        
        	        first += (g * (nodeSize + 1));
        	        last += (g * (nodeSize + 1));
        	        
        	        k = first;
        	        while (k <= last) {
        	                debug("evaluating 1: cumsum[%d] is %d cumsum[%d] is %d",
        	                        k + 1, cumsum[k + 1], k, cumsum[k]);
        	                if ( (cumsum[k + 1] - cumsum[k] == 0) ) {
        	                        k++;
        	                        continue;
                                }
        	                        
                                for (i = k; i <= last; i++) {
                                        
                                        debug("evaluating 2: cumsum[%d] is %d cumsum[%d] is %d",
                                                i + 1, cumsum[i + 1], i, cumsum[i]);
                                        if ( (cumsum [i + 1] - cumsum[i] <= 0) ||
                                                (	(i == last) &&
                                                        (cumsum[i] - cumsum[i - 1] > 0) ) ) {
		                                interval* intptr = &intervals[intervalCtr];
		                                if  ( (k == first) && (i == last) ) {
		                                        k = last + 1;
		                                        i = last + 1;
                                                        break;
                                                }
		                                intptr->begin = k - g * (nodeSize + 1);
		                                intptr->end = i - g * (nodeSize + 1);
		                                
		                                if (intptr->end < intptr->begin)
		                                        continue;
                                                intptr->numnodes = i - k + 1;
                                                intptr->size = cumsum[i + 1] - cumsum[k];
                                                intptr->gpu = g;
                                                intptr->level = switch_record_table[j].level;
                                                debug3("new interval %d, begin %d, end %d, size %d, level %d",
                                                        intervalCtr, intptr->begin, intptr->end, intptr->size, intptr->level);
                                                intervalCtr++;
                                        	nodesetCount[g]++;
                                        	k = i + 1;
                                        	break;
                                        }
                                }
                                k++;
        	        }
        	}
        	
        	// for all switch j do
        	// from switch[j].first to switch[j].last
        	// first point cumsum increases, new interval        	
        	// if cumsum stays same, interval ends
        	// assign switch[j].level to interval      	        	
        	
        	
        }
        
        /* interval debug lines */
        for (i = 0; i < intervalCtr; i++) {
                debug("interval id: %d, begin: %d, end: %d, size: %d, numnodes: %d, gpu: %d",
                        i, intervals[i].begin, intervals[i].end, intervals[i].size,
                        intervals[i].numnodes, intervals[i].gpu);
        }
/*
        for (g = 0; g <= max_gpu; g++) {
        	for (i = 0; i < (g + 1) * (nodeSize + 1); i++) 
	                info("cumsum of g %d i %d is %d", g, i, cumsum[i]);
        }
*/
        
}

// class generation for node-only jobs
void classGenerationN(int job_idx) 
{ 
        int i, j, k, l, cores, m, p, end_node, ret;
        int firstContigClass, firstClass, lastClass, lastContClass, lastAlignedClass, numClass;
        bool ok;
	debug4("entering classmap loop, classmapctr %d",classMapCtr);
        interval temp;
        int *nodes = (int *)malloc(nodeSize * sizeof(int));

	firstClass = classCtr;
        job_array[job_idx].firstBid = bidCtr;

        firstContigClass = classCtr;
	/* contiguous aligned bids */
	for (i = 0; i < intervalCtr; i++) {
	        if (classCtr >= MAXCLASSES) {
			debug4("max number of classes (%d) reached",MAXCLASSES);
			break;
		}		       
		int g = intervals[i].gpu;
                if ( (g >= job_array[job_idx].gpu) &&
			(g <= job_array[job_idx].gpu_max) && 
                	(intervals[i].size >= job_array[job_idx].min_cpus) &&
                	(intervals[i].numnodes >= job_array[job_idx].min_nodes) ) {
                        int offset = g * (nodeSize + 1);
                        // align to beginning of interval
                        k = intervals[i].begin;
               		end_node = MIN(job_array[job_idx].max_nodes, intervals[i].end - k + 1);
                       	cores = cumsum[k + end_node + offset] - cumsum[k + offset];
                       	debug4("begin node %d end_node %d cores %d ",k,end_node,cores);
                        if ( (cores >= job_array[job_idx].min_cpus) ) {
                                ok = true;
                                if (job_array[job_idx].cpus_per_node > 0)
                                        for (j = k; j < k + end_node; j++) {
                                                if (node_array[j].rem_cpus < job_array[job_idx].cpus_per_node) {
                                                        ok = false;
                                                }
                                        }
                                if (ok) {
                                        debug4("creating class for cores %d",cores);
                                	cArray[classCtr].numNodes = end_node;
                                        if (job_array[job_idx].cpus_per_node > 0)
                                        	cArray[classCtr].numCores = end_node * job_array[job_idx].cpus_per_node;
                                        else
                                                cArray[classCtr].numCores = MIN(cores, job_array[job_idx].max_cpus);
                                        cArray[classCtr].numGpus = g;
                                        cArray[classCtr].nodesUsed = (int *)malloc(cArray[classCtr].numNodes * sizeof(int));
                                        int sum = 0;
					cArray[classCtr].preference = preferenceCalculation
					        (cArray[classCtr].numNodes, intervals[i].level, 0, 0, g, max_gpu);
                                        for (m = 0; m < cArray[classCtr].numNodes; m++) {
                                        	cArray[classCtr].nodesUsed[m] = k + m;
                                        	debug5("nodeUsed %d: %d",m,cArray[classCtr].nodesUsed[m]);
                                        	sum += nArray[k + m];
                                        }
                                        cArray[classCtr].sumBids = sum;
                                       	classCtr++;
                                }
                        }
                        // align to end of interval
                        k = intervals[i].end - job_array[job_idx].min_nodes + 1;
               		end_node = MIN(job_array[job_idx].max_nodes, intervals[i].end - k + 1);
                       	cores = cumsum[k + end_node + offset] - cumsum[k + offset];
                       	debug4("begin node %d end_node %d cores %d ",k,end_node,cores);
                        if ( (cores >= job_array[job_idx].min_cpus) ) {
                                ok = true;
                                if (job_array[job_idx].cpus_per_node > 0)
                                        for (j = k; j < k + end_node; j++) {
                                                if (node_array[j].rem_cpus < job_array[job_idx].cpus_per_node) {
                                                        ok = false;
                                                }
                                        }
                                if (ok) {
                                        debug4("creating class for cores %d",cores);
                                	cArray[classCtr].numNodes = end_node;
                                        if (job_array[job_idx].cpus_per_node > 0)
                                        	cArray[classCtr].numCores = end_node * job_array[job_idx].cpus_per_node;
                                        else
                                                cArray[classCtr].numCores = MIN(cores, job_array[job_idx].max_cpus);
                                        cArray[classCtr].numGpus = g;
                                        cArray[classCtr].nodesUsed = (int *)malloc(cArray[classCtr].numNodes * sizeof(int));
                                        int sum = 0;
                                        cArray[classCtr].preference = preferenceCalculation
                                                (cArray[classCtr].numNodes, intervals[i].level, 0, 0, g, max_gpu);
                                        for (m = 0; m < cArray[classCtr].numNodes; m++) {
                                        	cArray[classCtr].nodesUsed[m] = k + m;
                                        	debug5("nodeUsed %d: %d",m,cArray[classCtr].nodesUsed[m]);
                                        	sum += nArray[k + m];
                                        }
                                        cArray[classCtr].sumBids = sum;
                                       	classCtr++;
                                }
			}
		}
	}

	debug("created %d aligned classes for job %d",classCtr - firstContigClass, job_idx);
        lastAlignedClass = classCtr;
	i = 0;
	debug4("trying to create bids for job_idx %d firstContigClass %d lastAlignedClass %d",
	        job_idx, firstContigClass, lastAlignedClass);
	numClass = lastAlignedClass - firstContigClass;
	// the job has numClass classes 
	for (j = firstContigClass; j < lastAlignedClass; j++) {
	        if (bidCtr - job_array[job_idx].firstBid >= (MAXBIDPERJOB/2) )
	                break;
		ret = newBid(cArray[j].numCores, job_idx, j,
			job_array[job_idx].priority, cArray[j].preference, 
			cArray[j].numNodes, cArray[j].nodesUsed, cArray[j].numGpus, 10);
                if (ret <= 0)
                        break;
	}

	debug("going on to non-aligned contig bids");
	
	// contiguous bids
	
	for (i = 0; i < intervalCtr; i++) {
		if (classCtr >= MAXCLASSES) {
			debug4("max number of classes (%d) reached",MAXCLASSES);
			break;
		}		       
		if (classCtr - firstClass >= MAXCLASSESPERJOB) {
			debug4("max number of classes per job (%d) reached for job %d",MAXCLASSESPERJOB,job_array[job_idx].job_id);
			break;
		}
		int g = intervals[i].gpu;
                if ( (g >= job_array[job_idx].gpu) &&
			(g <= job_array[job_idx].gpu_max) && 
                	(intervals[i].size >= job_array[job_idx].min_cpus) &&
//                	(intervals[i].size <= job_array[job_idx].max_cpus) &&
                	(intervals[i].numnodes >= job_array[job_idx].min_nodes) ) {
//                	(intervals[i].numnodes <= job_array[job_idx].max_nodes) ) {
                        int offset = g * (nodeSize + 1);
                      	for (k = intervals[i].begin; k <= intervals[i].end - job_array[job_idx].min_nodes + 1; k++) {
                      	        //k = begin_node, starting from interval's initial point
                      	        //end_node, min(k + max_node,intervals[i].end);
                		if (classCtr >= MAXCLASSES) {
                			debug4("max number of classes (%d) reached",MAXCLASSES);
                			break;
                		}		       
                		if (classCtr - firstClass >= MAXCLASSESPERJOB) {
                			debug4("max number of classes per job (%d) reached for job %d",MAXCLASSESPERJOB,job_array[job_idx].job_id);
                			break;
                		}
                		end_node = MIN(job_array[job_idx].max_nodes, intervals[i].end - k + 1);
                		
                		int numNodes = 0;
                		
                		ok = false;
                		int *usedNodes = (int *)malloc(nodeSize * sizeof(int));
                		if (job_array[job_idx].cpus_per_node > 0) {
                		        for (j = k; j <= intervals[i].end; j++) {
                		                if (node_array[j].rem_cpus >= job_array[job_idx].cpus_per_node) {
                		                        usedNodes[numNodes++] = j;
                                                }
                                                if (numNodes == job_array[job_idx].min_nodes) {
                                                        ok = true;
                                                        break;
                                                }
                                        }
                		}
                		else 
                		{
                		        for (j = k; j <= intervals[i].end; j++) {
                		                if (node_array[j].rem_cpus > 0) {
                		                        usedNodes[numNodes++] = j;
                                                }
                                                if ( (numNodes == job_array[job_idx].min_nodes) && 
                                                        (cumsum[k + numNodes + offset] - cumsum[k + offset] >= job_array[job_idx].min_cpus) ) {
                                                        ok = true;
                                                        break;
                                                }
                                        }
                		}
                		
                		if (!ok) {
                		        free(usedNodes);
                		        continue;
                                }
                
                        	cores = cumsum[k + numNodes + offset + 1] - cumsum[k + offset];
                        	
                        	debug4("begin node %d end_node %d cores %d ",k,end_node,cores);
                                if ( (cores >= job_array[job_idx].min_cpus) ) {
                                        /*
                                        ok = true;
                                        if (job_array[job_idx].cpus_per_node > 0)
                                        for (j = k; j < k + end_node; j++) {
                                                if (node_array[j].rem_cpus < job_array[job_idx].cpus_per_node) {
                                                        ok = false;
                                                }
                                        }
                                        */
                                        if (ok) {
                                	cArray[classCtr].numNodes = numNodes;
                                        if (job_array[job_idx].cpus_per_node > 0)
                                        	cArray[classCtr].numCores = numNodes * job_array[job_idx].cpus_per_node;
                                        else
                                                cArray[classCtr].numCores = MIN(cores, job_array[job_idx].max_cpus);
                                        cArray[classCtr].numGpus = g;
                                        cArray[classCtr].nodesUsed = (int *)malloc(cArray[classCtr].numNodes * sizeof(int));
                                        int sum = 0;
                                        cArray[classCtr].preference = preferenceCalculation
                                                (cArray[classCtr].numNodes, intervals[i].level, 0, 0, g, max_gpu);
                                        debug4("creating class for cores %d pref %.2f",cores,cArray[classCtr].preference);
                                        for (m = 0; m < cArray[classCtr].numNodes; m++) {
                                        	cArray[classCtr].nodesUsed[m] = usedNodes[m];
                                                sum += nArray[usedNodes[m]];
                                        	//debug5("nodeUsed %d: %d",m,cArray[classCtr].nodesUsed[m]);
                                        }
                                        cArray[classCtr].sumBids = sum;
                                       	classCtr++;
                                       	}
				}
               		        free(usedNodes);
				
				
			}
		}
	}
	
	debug4("created %d contig classes for job %d",classCtr - lastAlignedClass, job_idx);

	debug4("created %d classes for job %d",classCtr - lastAlignedClass, job_idx);
        lastContClass = classCtr;
	i = bidCtr - job_array[job_idx].firstBid;
	debug4("trying to create bids for job_idx %d lastAlignedClass %d lastContClass %d",
	        job_idx, lastAlignedClass, lastContClass);
	numClass = lastContClass - lastAlignedClass;
	// the job has numClass classes 
	int *contigbids = (int *) malloc((MAXBIDPERJOB - i) * sizeof(int));
	k = 0;
	while ((i < MAXBIDPERJOB) && (i < numClass)) {
	        int max_pref_idx = -1;
	        double max_pref = MINPREF;
	        int max_sum = LARGENUMBER;
	        for (j = lastAlignedClass; j < lastContClass; j++) {
	                for (l = 0; l < k; l++)
	                        if (contigbids[l] == j)
	                                continue;
			//if ((cArray[j].preference >= max_pref) && (cArray[j].sumBids <= max_sum)) {
        		if (cArray[j].preference > max_pref) {
                                max_pref = cArray[j].preference;
				max_sum = cArray[j].sumBids;
                                max_pref_idx = j;
                        }	                
                }
                if (max_pref_idx == -1) {
                        break;
                }
		debug4("class with max pref (%.2f) is %d",max_pref, max_pref_idx);
		ret = newBid(cArray[max_pref_idx].numCores, job_idx, max_pref_idx,
			job_array[job_idx].priority, cArray[max_pref_idx].preference, 
			cArray[max_pref_idx].numNodes, cArray[max_pref_idx].nodesUsed, cArray[max_pref_idx].numGpus, 11);
                if (ret >= 0) {
                        i++;
                        contigbids[k++] = max_pref_idx;
                }
                else if (ret == -1)
                        break;
	}
	free(contigbids);


	debug("going on to non-contig bids");

	// non-contiguous bids
	// k: non-contiguousness level
	// depth first search
	if (0) {
	if (job_array[job_idx].contiguous != 1) {

	for (i = 0; i < intervalCtr; i++) {
	        if (intervals[i].level > 0)
	                break;
		temp.size = intervals[i].size;
		temp.gpu = intervals[i].gpu;
		if ( (temp.gpu < job_array[job_idx].gpu) || (temp.gpu > job_array[job_idx].gpu_max) )
			continue;
		temp.numnodes = intervals[i].numnodes;
		temp.begin = intervals[i].begin;
		temp.end = intervals[i].end;
		for (p = 0; p < temp.numnodes; p++) {
		        if (p > nodeSize)
        		        fatal("P %d IS GREATER THAN NODESIZE %d",p,nodeSize);
                        nodes[p] = intervals[i].begin + p;
                }
                debug4("testing non-contig nodeset starting from interval no %d",i);
		int contig = 1;
		for (j = i + 1; j < intervalCtr; j++) {
		        if (intervals[j].level > 0)
		                break;
		        if (contig >= NONCONTIGLEVEL) {
		                debug4("max non contiguity level reached.");
		                break;
                        }
			if (classCtr >= MAXCLASSES) {
				debug4("max number of classes (%d) reached",MAXCLASSES);
				break;
			}		       
			if (classCtr - firstClass >= MAXCLASSESPERJOB) {
				debug4("max number of classes per job (%d) reached for job %d",MAXCLASSESPERJOB,job_array[job_idx].job_id);
				break;
			}

			if (intervals[j].gpu > intervals[i].gpu)
                                break;
			if (intervals[j].gpu == intervals[i].gpu) {
			        debug4("included interval no %d to the nodeset beginning with interval %d",j,i);
			        contig++;
			        //debug4("interval %d (%d nodes) and interval %d (%d nodes)have same gpu, combining",
			                 //j,intervals[j].numnodes,i,intervals[i].numnodes);
				temp.size += intervals[j].size;
				//debug4("size is now: %d", temp.size);
				//debug4("realloc'ed nodes");

				for (p = 0; p < intervals[j].numnodes; p++) {
				        //debug5("intervals[%d].nodes(%d) is: %d",j,p,intervals[j].nodes[p]);
                                        nodes[p + temp.numnodes] = intervals[j].begin + p;
                		        if (p + temp.numnodes > nodeSize)
                		                fatal("P %d +temp.numnodes %d IS GREATER THAN NODESIZE %d",p,temp.numnodes,nodeSize);
                                        //intervals[j].nodes[p];
				        //debug5("nodes element %d is %d",p + temp.numnodes,nodes[p + temp.numnodes]);	
				        //debug5("interval %d nodes %d: %d",j,p,intervals[j].nodes[p]);
                                }
				temp.numnodes += intervals[j].numnodes;
				//debug4("nodes in temp interval: (%d)",temp.numnodes);
				//xfor (p = 0; p < temp.numnodes; p++)
				        //xnodes[p] = 1;

				int g = temp.gpu;
		                if ( (g >= job_array[job_idx].gpu) &&
					(g <= job_array[job_idx].gpu_max) && 
	        	        	(temp.size >= job_array[job_idx].min_cpus) &&
	        		       	(temp.numnodes >= job_array[job_idx].min_nodes) ) {
		                      	for (k = 0; k < temp.numnodes - job_array[job_idx].min_nodes + 1; k++) {
		                      	        if (classCtr >= MAXCLASSES) {
		                      	                debug4("max number of classes (%d) reached",MAXCLASSES);
		                      	                break;
                                                }
					       	if (classCtr - firstClass >= MAXCLASSESPERJOB) {
  				                        debug4("max number of classes per job (%d) reached for job %d",MAXCLASSESPERJOB,job_array[job_idx].job_id);
                        				break;
						}
						cores = 0;
						//debug4("job id: %d cores for noncontig class creation",job_array[job_idx].job_id);	
                                		end_node = MIN(job_array[job_idx].max_nodes, temp.numnodes - k);
						for (p = k; p < k + end_node; p++) {
							cores += node_array[nodes[p]].rem_cpus;
							//debug4("id: %d node %d remcpu %d total %d",
							//p,nodes[p],node_array[nodes[p]].rem_cpus,cores);
						}
						//debug("%d segments, %d cores", contig, cores);
		                                if ( (cores >= job_array[job_idx].min_cpus) ) {
		                                        ok = true;
                                                        if (job_array[job_idx].cpus_per_node > 0)
                                                                for (m = k; m < k + end_node; m++) {
                                                                        if (node_array[nodes[m]].rem_cpus < job_array[job_idx].cpus_per_node) {
                                                                                ok = false;
                                                                        }
                                                                }
                                                        if (ok) {
                                                        debug4("creating class for cores %d",cores);
                		                	cArray[classCtr].numNodes = end_node;
                                                        if (job_array[job_idx].cpus_per_node > 0)
                                                        	cArray[classCtr].numCores = end_node * job_array[job_idx].cpus_per_node;
                                                        else
                                                                cArray[classCtr].numCores = cores;
		                                        cArray[classCtr].numGpus = g;
                		                        cArray[classCtr].nodesUsed = (int *)malloc(cArray[classCtr].numNodes * sizeof(int));
                                                        int sum = 0;
                                                        cArray[classCtr].preference = preferenceCalculation
                                                                (cArray[classCtr].numNodes, intervals[i].level, i, j, g, max_gpu); 
		                                        for (m = 0; m < cArray[classCtr].numNodes; m++) {
		                                                //debug4("trying to access nodes %d : %d",k+m,nodes[k + m]);
                		                        	cArray[classCtr].nodesUsed[m] = nodes[k + m];
                                                                sum += nArray[nodes[k + m]];
                                		       	}
                                                        cArray[classCtr].sumBids = sum;
                                		       	classCtr++;
                                		       	}
						}
					}
				}
			}
		}
                //free(nodes);
	}
	
	debug5("created %d classes for job %d",classCtr - lastContClass, job_idx);
        lastClass = classCtr;
	i = bidCtr - job_array[job_idx].firstBid;
	debug3("trying to create bids for job_idx %d firstContigClass %d lastClass %d",
	        job_idx, firstContigClass, lastClass);
	numClass = lastClass - lastContClass;
	// the job has numClass classes 
	k = 0;
        int *noncontigbids = (int *) malloc((MAXBIDPERJOB - i) * sizeof(int));
	while ((i < MAXBIDPERJOB) && (i < numClass)) {
	        int max_pref_idx = -1, l, ret;
	        double max_pref = MINPREF;
	        int max_sum = LARGENUMBER;
//SIL
//	        for (j = lastContClass; j < lastClass; j++) {
//	                if (cArray[j].preference > preference) {
//	                        for (l = 0; l < k; l++) {
//	                                if (j == noncontigbids[l])
//	                                        continue;
//	                        }
//	                        max_pref_idx = j;
	                        //preference = cArray[j].preference;
	                //}
//                }
/////SILKAPA
	        for (j = lastContClass; j < lastClass; j++) {
	                for (l = 0; l < k; l++)
	                        if (noncontigbids[l] == j)
	                                continue;
			if ((cArray[j].preference >= max_pref) || (cArray[j].sumBids <= max_sum)) {
        		//if (cArray[j].preference >= max_pref) {
                                max_pref = cArray[j].preference;
				max_sum = cArray[j].sumBids;
                                max_pref_idx = j;
                        }	                
                }
                if (max_pref_idx == -1) {
                        break;
                }
		debug3("class with maximum preference (%.2f) is %d",max_pref, max_pref_idx);
		ret = newBid(cArray[max_pref_idx].numCores, job_idx, max_pref_idx,
			job_array[job_idx].priority, cArray[max_pref_idx].preference, 
			cArray[max_pref_idx].numNodes, cArray[max_pref_idx].nodesUsed, cArray[max_pref_idx].numGpus, 12);
                if (ret >= 0)
                        i++;
                else if (ret == -1)
                        break;
                noncontigbids[k++] = max_pref_idx;
	}
	free(noncontigbids);
	}
	}

	debug("freeing nodes");
	job_array[job_idx].lastBid = bidCtr;
	free(nodes);
        debug("freed nodes");
}

// class generation for core-only jobs

void classGenerationC(int job_idx)
{ 
        int i, j = 0, k, l, cores, m, ret;
        int firstContigClass, firstClass, lastContClass, lastAlignedClass, numClass;
        int *nodes = (int*) malloc(nodeSize * sizeof(int));
        job_array[job_idx].firstBid = bidCtr;
        firstClass = classCtr;
        
        debug3("entering interval loop, intervalCtr %d, job id %d",intervalCtr,job_array[job_idx].job_id);
	firstContigClass = classCtr;
        for (i = 0; i < intervalCtr; i++) {
		int g = intervals[i].gpu;
                debug3("interval %d gpu %d , job gpu %d-%d",i,g,job_array[job_idx].gpu,job_array[job_idx].gpu_max);		
                 if ( (g < job_array[job_idx].gpu) || (g > job_array[job_idx].gpu_max) ) {
			debug2("job %d gpu ([%d-%d] count not applicable to interval %d", 
				job_idx, job_array[job_idx].gpu, job_array[job_idx].gpu_max, i);
                        continue;
		}
                 if ( (intervals[i].size < job_array[job_idx].min_cpus) ) {
			debug3("job %d cpu count not applicable to interval %d", job_idx, i);
			continue;
		}
                debug3("sth3 int between %d and %d ",intervals[i].begin, intervals[i].end);

	                 for (k = intervals[i].end; k >= intervals[i].begin; k--) {
                                      if (classCtr >= MAXCLASSES)
                                              break;
                                      if (classCtr - firstClass >= MAXCLASSESPERJOB)
                                              break;
                        debug3("sth4");
                                      cores = cumsum[intervals[i].end + 1] - cumsum[k];
                                      if ( (cores < job_array[job_idx].min_cpus) || (intervals[i].end + 1 - k > job_array[job_idx].min_cpus)) 
				   	      continue;
                                      
					debug3("generating right-aligned bid for job %d",job_array[job_idx].job_id);
                                        cArray[classCtr].numNodes = intervals[i].end - k + 1;
                                        cArray[classCtr].numCores = cores;
                                        cArray[classCtr].numGpus = g;
                                        debug4("creating nodesUsed size %d",cArray[classCtr].numNodes);
                                        cArray[classCtr].nodesUsed = (int *)malloc(cArray[classCtr].numNodes * sizeof(int));
                                        cArray[classCtr].preference = preferenceCalculation
                                                        (cArray[classCtr].numNodes, intervals[i].level, 0, 0, g, max_gpu);
                                        debug4("filling nodesUsed");
                                        int sum = 0;
                                        for (m = 0; m < cArray[classCtr].numNodes; m++) {
                                                      debug5("nodesUsed element %d is %d",m,k+m);
                                                      cArray[classCtr].nodesUsed[m] = k + m;
                                                      sum += nArray[k + m];
                                        }  
                                        cArray[classCtr].sumBids = sum;
                                        classCtr++;
                                        //debug3("class ctr now %d",classCtr);
                                        break;

                             }

                             for (k = intervals[i].begin; k <= intervals[i].end; k++) {
                                      if (classCtr >= MAXCLASSES)
                                              break;
                                      if (classCtr - firstClass >= MAXCLASSESPERJOB)
                                              break;
                                      cores = cumsum[k + 1] - cumsum[intervals[i].begin];
                                      if ( (cores < job_array[job_idx].min_cpus) || (k + 1 - intervals[i].begin > job_array[job_idx].min_cpus))
                                              continue;
                                      
                                              debug3("generating left-aligned bid for job %d",job_array[job_idx].job_id);
                                              cArray[classCtr].numNodes = k - intervals[i].begin + 1;
                                              cArray[classCtr].numCores = cores;
                                              cArray[classCtr].numGpus = g;
                                              debug4("creating nodesUsed size %d",cArray[classCtr].numNodes);
                                              cArray[classCtr].nodesUsed = (int *)malloc(cArray[classCtr].numNodes * sizeof(int));
                                              cArray[classCtr].preference = preferenceCalculation
                                                        (cArray[classCtr].numNodes, intervals[i].level, 0, 0, g, max_gpu);
                                              debug4("filling nodesUsed");
                                              int sum = 0;
                                              for (m = 0; m < cArray[classCtr].numNodes; m++) {
                                                      debug5("nodesUsed element %d is %d",m,k+m);
                                                      cArray[classCtr].nodesUsed[m] = intervals[i].begin + m;
                                                      sum += nArray[intervals[i].begin + m];
                                              }  
                                              cArray[classCtr].sumBids = sum;
                                              classCtr++;
                                              //debug3("class ctr now %d",classCtr);
                                              break;
                             }
        }

	debug3("created %d aligned classes for job %d",classCtr - firstContigClass, job_idx);
        lastAlignedClass = classCtr;
	i = 0;
	debug("trying to create aligned bids for job_idx %d firstContigClass %d lastAlignedClass %d",
	        job_idx, firstContigClass, lastAlignedClass);
	numClass = lastAlignedClass - firstContigClass;
	// the job has numClass classes 
	for (j = firstContigClass; j < lastAlignedClass; j++) {
	        if (bidCtr - job_array[job_idx].firstBid >= MAXBIDPERJOB)
	                break;
		ret = newBid(job_array[job_idx].min_cpus, job_idx, j,
			job_array[job_idx].priority, cArray[j].preference, 
			cArray[j].numNodes, cArray[j].nodesUsed, cArray[j].numGpus, 1);
        	if (ret == -1)
        	        break;
                else if (ret >= 0)
                        i++;
	}

	// non-aligned contiguous bids 
	// k: non-contiguousness level
	// depth first search 

        for (i = 0; i < intervalCtr; i++) {
		int g = intervals[i].gpu;
                 if ( (g < job_array[job_idx].gpu) || (g > job_array[job_idx].gpu_max) )
                        continue;
                 if ( (intervals[i].size >= job_array[job_idx].min_cpus) ) {
			for (l = intervals[i].begin; l <= intervals[i].end; l++) {
                             for (k = l; k < intervals[i].end; k++) {
                                      if (classCtr >= MAXCLASSES)
                                              break;
                                      if (classCtr - firstClass >= MAXCLASSESPERJOB)
                                              break;
                                      cores = cumsum[k + 1] - cumsum[l];
					if ( (cores < job_array[job_idx].min_cpus) || (k + 1 - l > job_array[job_idx].min_cpus) )
						continue;
                                              cArray[classCtr].numNodes = k + 1 - l;
                                              cArray[classCtr].numCores = cores;
                                              cArray[classCtr].numGpus = g;
                                              debug4("creating nodesUsed size %d",cArray[classCtr].numNodes);
                                              cArray[classCtr].nodesUsed = (int *)malloc(cArray[classCtr].numNodes * sizeof(int));
                                              cArray[classCtr].preference = preferenceCalculation
                                                        (cArray[classCtr].numNodes, intervals[i].level, 0, 0, g, max_gpu);
                                              debug4("filling nodesUsed");
                                              int sum = 0;
                                              for (m = 0; m < cArray[classCtr].numNodes; m++) {
                                                      debug5("nodesUsed element %d is %d",m,k+m);
                                                      cArray[classCtr].nodesUsed[m] = l + m;
                                                      sum += nArray[l + m];
                                              }  
                                              cArray[classCtr].sumBids = sum;
                                              debug5("created class %d",classCtr);
                                              classCtr++;
                                              //debug3("class ctr now %d",classCtr);
                                              j++;
						break;
                             }
			}
                 }
        }

	debug3("created %d classes for job %d",classCtr - lastAlignedClass, job_idx);
        lastContClass = classCtr;
	i = 0;
	debug("trying to create bids for job_idx %d lastAlignedClass %d lastContClass %d",
	        job_idx, lastAlignedClass, lastContClass);
	numClass = lastContClass - lastAlignedClass;
	// the job has numClass classes
	int *contigbids = (int *) malloc((MAXBIDPERJOB - i) * sizeof(int));
	k = 0;

	while ((i < MAXBIDPERJOB) && (i < numClass)) {
	        int max_pref_idx = 0;
	        double max_pref = MINPREF;
		int max_sum = LARGENUMBER;
	        for (j = lastAlignedClass; j < lastContClass; j++) {
	                for (l = 0; l < k; l++)
	                        if (contigbids[l] == j)
	                                continue;
			//if ((cArray[j].preference <= max_pref) && (cArray[j].sumBids <= max_sum)) {
        		if (cArray[j].preference > max_pref) {
                                max_pref = cArray[j].preference;
				max_sum = cArray[j].sumBids;
                                max_pref_idx = j;
                        }	                
                }
                if (max_pref_idx == -1) {
                        break;
                }
		debug3("class with max pref (%.2f) is %d",max_pref, max_pref_idx);
		ret = newBid(cArray[max_pref_idx].numCores, job_idx, max_pref_idx,
			job_array[job_idx].priority, cArray[max_pref_idx].preference, 
			cArray[max_pref_idx].numNodes, cArray[max_pref_idx].nodesUsed, cArray[max_pref_idx].numGpus, 2);
                if (ret >= 0) {
                        i++;
                        contigbids[k++] = max_pref_idx;
                }
                else if (ret == -1)
                        break;
	}
	free(contigbids);

	free(nodes);
	job_array[job_idx].lastBid = bidCtr;
}
                        

inline int
populatebynonzero (CPXENVptr env, CPXLPptr lp, int m, int n)
{
	int NUMCOLS = bidCtr; 
	int NUMROWS = n + 2 * m;
	int NUMNZ = bidCtr + 2 * (jobNodeCtr);
	int NZc = 0; /* nonzero counter */
	
	int status = 0;
	double *obj = NULL;
	obj = (double*)malloc(NUMCOLS * sizeof(double));
	double *lb = (double*)malloc(NUMCOLS * sizeof(double));
	double *ub = (double*)malloc(NUMCOLS * sizeof(double));
	double *rhs = (double*)malloc(NUMROWS * sizeof(double));
	char *ctype = (char*)malloc(NUMCOLS * sizeof(char));
	char *sense = (char*)malloc(NUMROWS * sizeof(char));
	/*
	char **colname = (char**)malloc(NUMCOLS * sizeof(char*));
	char str[10];
	*/
	int *rowlist = (int*)malloc(NUMNZ * sizeof(int));
	int *collist = (int*)malloc(NUMNZ * sizeof(int));
	double *vallist = (double*)malloc(NUMNZ * sizeof(double));
	int i, j, k, c, tempCtr;

	CPXchgobjsen (env, lp, CPX_MAX);  /* Problem is maximization */
	
	debug3("bidCtr %d jobNodeCtr %d NUMROWS %d NUMCOLS %d", bidCtr, jobNodeCtr,NUMROWS,NUMCOLS);
	debug3("n %d m %d NUMNZ %d", n, m, NUMNZ);

	/* row definitions */
	
	/* constraints (2) b_jc <= 1 */
	for (j = 0; j < n; j++) {
		sense[j] = 'L';
		rhs[j] = 1.0;
	}
	
	/* constraints (3) and (4) */
	for (j = n; j < n + m; j++) {
	        i = j - n;
		sense[j] = 'L';
		rhs[j] = 1.0 * node_array[i].rem_cpus;
		sense[m + j] = 'L';
		rhs[m + j] = 1.0 * node_array[i].rem_gpus;
	}
	
	
	status = CPXnewrows (env, lp, NUMROWS, rhs, sense, NULL, NULL);
	if ( status ) 
	{
		debug3("cpxnewrows failed.");	
		goto TERMINATE;
	}

	/* column definitions */	

	/* b_jc definitions */
	for (j = 0; j < bidCtr; j++) {
		/*
		sprintf(str, "b_%d",j);
		colname[j] = str;
		*/
		ctype[j] = CPX_BINARY;
		lb[j] = 0.0;
		ub[j] = 1.0;
		
	}
	
	for (k = 0; k < bidCtr; k++) {
		debug3("bid %d prio %d preference %f, alpha %.2f",k,bids[k].priority,bids[k].preference, alpha);
		obj[k] = (bids[k].priority - bids[k].preference * alpha) * bids[k].amount;
//		obj[k] = (bids[k].priority + bids[k].preference * alpha);
	}
	
	for (k = bidCtr; k < NUMCOLS; k++) {
	        obj[k] = 0.0;
	}
	
	status = CPXnewcols (env, lp, NUMCOLS, obj, lb, ub, ctype, NULL);
	if ( status ) {
                debug3("cpxnewcols failed.");
		goto TERMINATE;
	}

	/* constraints */
	
	/* constraint (2) coefficients: 
	   sum_bjc <= 1, c in B_j, for all j */
	for (j = 0; j < n; j++) {
	        debug("job %d firstbid %d lastbid %d",j,job_array[j].firstBid,job_array[j].lastBid);
		for (k = job_array[j].firstBid; k < job_array[j].lastBid; k++) {
			rowlist[NZc] = j;
//			debug("row %d, col %d, NZc %d",j,k,NZc);
			collist[NZc] = k;
//                      debug3("col index of %d is %d",NZc, collist[NZc]);
			vallist[NZc++] = 1.0;
		}
	}
	/* NZc = bidCtr */
	debug3("NZc is now %d, should be %d",NZc, bidCtr);

        debug("constraint 3 start");
	/* constraint (3) coefficients: b_jc * T_cn <= A_n^cpu */
	tempCtr = 2 * n + bidCtr;
	for (j = 0; j < n; j++) {
		for (k = job_array[j].firstBid; k < job_array[j].lastBid; k++) {
			for (c = bids[k].firstNode; c < bids[k].lastNode; c++) {
				rowlist[NZc] = n + jobNodeName[c];
				collist[NZc] = k;
                                vallist[NZc++] = T[c];
//				debug3("row %d col %d jobnodename %d", rowlist[NZc-1], collist[NZc-1], jobNodeName[c]);
                        }
                }
        }

        debug("constraint 4 start");
        /* constraint (4) coefficients: U%%X
        U_cn * R_j^gpu <= A_n^gpu */
        tempCtr = 2 * n + bidCtr;
        for (j = 0; j < n; j++) {
                for (k = job_array[j].firstBid; k < job_array[j].lastBid; k++) {
                        for (c = bids[k].firstNode; c < bids[k].lastNode; c++) {
                                rowlist[NZc] = n + m + jobNodeName[c];
                                collist[NZc] = k;
                                vallist[NZc++] = bids[k].gpu;
//                              debug3("row %d col %d jobnodename %d", rowlist[NZc-1], collist[NZc-1], jobNodeName[c]);
                        }
                }
        }
	/* NZc = 3 * bidCtr + 9 * jobNodeCtr + m * n * 2 */	
	debug3("NZc is now %d, should be %d",NZc, bidCtr + 2 * jobNodeCtr);
	
	/*nzc = num_bids*/
	
	status = CPXchgcoeflist (env, lp, NZc, rowlist, collist, vallist);   
	debug3("status from change coef list: %d",status);
	if ( status ) {
                debug3("cpxchgcoeflist failed.");
		goto TERMINATE;
	}

TERMINATE:
	free_and_null ((char **) &obj);

	free_and_null ((char **) &lb);
	free_and_null ((char **) &ub);
	free_and_null ((char **) &rhs);
	free_and_null ((char **) &sense);
	free_and_null ((char **) &rowlist);
	free_and_null ((char **) &collist);
	free_and_null ((char **) &vallist);
	debug("freed all, bb");

	return (status);
} 



/* 
returns 0 if solution found
	2 if time limit hit
*/
extern int solve_allocation(int m, int n, int timeout,
			sched_nodeinfo_t* _node_array, solver_job_list_t* _job_array,
			int max_bid_count)
{
	char filename[256];
	solver_job_list_t *sjob_ptr;
	struct job_details *job_det_ptr;
	int k, c, i;
	bool half = false;
	uint32_t begin_time = time(NULL), mid_time;
	uint32_t time1;
	uint16_t dummy;
	double objval;
	double *x = NULL;
	double *pi = NULL;
	double *slack = NULL;
	double *dj = NULL;

	CPXENVptr env = NULL;
	CPXLPptr lp = NULL;
	int status = 0, status2 = 0, j, cur_numrows, cur_numcols;
	FILE *log;
	
	/* set initial values */
        node_array = _node_array;
        job_array = _job_array;
        nodeSize = m;
        windowSize = n;

	debug3("window size %d", windowSize);
	for (i = 0; i < windowSize; i++) {
		debug3("job id %d",_job_array[i].job_id);
	}

	bidCtr = 0;
	classMapCtr = 0;
	classCtr = 0;
	jobNodeCtr = 0;
	maxBids = max_bid_count;

	jobNodeIdx = (int *)malloc(MAXJOBNODE * sizeof(int));
	jobNodeName = (int *)malloc(MAXJOBNODE * sizeof(int));
	T = (int *)malloc(MAXJOBNODE * sizeof(int));
	// number of class types cannot exceed window size
	//classMap = (class_map *)malloc(windowSize * sizeof(class_map));
	intervals = (interval *)malloc(MAXINTERVALS * sizeof(interval));
	nArray = (int *)malloc(nodeSize * sizeof(int));
	for (i = 0; i < nodeSize; i++)
	        nArray[i] = 0;

	/* find minPrioDiff */
        uint32_t minPrioDiff = LARGENUMBER;
	if (windowSize == 1) {
	        minPrioDiff = 1;
        } else {
        	for (i = 0; i < windowSize; i++) {
        		for (j = i + 1; j < windowSize; j++) {
        			uint32_t diff = abs(job_array[i].priority - job_array[j].priority); 
        	                if (diff < minPrioDiff) {
                	                minPrioDiff = diff;
        	                }
        		}
        	}
        }
	        
	/* cumsum generation */
	time1 = time(NULL);
	cumSumGeneration();
	debug2("timer: cumsum took %u",(uint16_t)(time(NULL)-time1));
	
	/* call bid generation 
	   this includes class generation 
	*/
	bids = (bid *)malloc(maxBids * sizeof(bid));
	cArray = (class *)malloc(MAXCLASSES * sizeof(class));
	time1 = time(NULL);

	//slurmBids();
        //slurmBids icin
        temp_node_array = (sched_nodeinfo_t*)
                malloc(node_record_count * sizeof(sched_nodeinfo_t));
        for (i = 0; i < nodeSize; i++) {
                temp_node_array[i].rem_cpus = node_array[i].rem_cpus;
        }
        
        /*
        if (switch_record_cnt && switch_record_table) {
                info("WE HAVE A WINNER");
        }
        
        info("WIN: %d", switch_record_cnt);
        info("WIN: %d", switch_record_table);
        
        for (j = 0; j < switch_record_cnt; j++) {
                int first, last;
                first = bit_ffs(switch_record_table[j].node_bitmap);
                last = bit_fls(switch_record_table[j].node_bitmap);
                int sum = 0;
                for (k = first; k <= last; k++) {
                        sum += node_array[k].rem_cpus;
                        debug3("switch: %d node: %d rem: %d sumnow: %d",
                                j, k, node_array[k].rem_cpus, sum);
                }
                debug2("TOTAL WIN for switch %d level: %d [%d-%d]: %d",
                        j, switch_record_table[j].level, first, last, sum);
        }
        */
        maxLevel = 0;
        for (j = 0; j < switch_record_cnt; j++) 
                if (switch_record_table[j].level > maxLevel)
                        maxLevel = switch_record_table[j].level;
                        
        maxLevel++;
                
        
        
        // switch_record_table[i].node_bitmap



	for (j = 0; j < windowSize; j++) {
	        if (classCtr >= MAXCLASSES) {
	                debug3("max classes reached in job %d of window %d",j,windowSize);
 		        job_array[j].firstBid = bidCtr;
 		        job_array[j].lastBid = bidCtr;
                } else if (bidCtr >= maxBids) {
	                debug3("max bids reached in job %d of window %d",j,windowSize);
 		        job_array[j].firstBid = bidCtr;
 		        job_array[j].lastBid = bidCtr;
                } else if (job_array[j].min_nodes > 0) {
 		        classGenerationN(j);
 		} else {
                        classGenerationC(j);
                }
	}

	for (j = 0; j < windowSize; j++) {
		solver_job_list_t* jobptr = &job_array[j];
		info("scheduling: job %d, id %d firstBid: %d, lastBid: %d, total %d",
			j, jobptr->job_id, jobptr->firstBid, jobptr->lastBid,
			jobptr->lastBid - jobptr->firstBid);
	}

        for (j = 0; j < windowSize; j++)
                job_array[j].alloc_total = 0;

	if (bidCtr == 0) {
		debug2("No bids formed, no IP solving necessary.");
	//	return 0;
	}
	
        alpha = (double)minPrioDiff / 3;
        debug2("minPrio is %d, bidCtr is %d, alpha is %.2f",minPrioDiff,bidCtr,alpha);
        
	debug2("timer: bid generation took %u",(uint16_t)(time(NULL)-time1));
	/* buradan oncesine yaziyorum herseyi */
                                                                                        	
        /*
	char envstr[256];
	sprintf(envstr,"ILOG_LICENSE_FILE=%s",get_cplex_license_address());
	if ( envstr != NULL ) {
		CPXputenv (envstr);
	}
	*/

	env = CPXopenCPLEX (&status);
	if ( env == NULL ) {
		char  errmsg[1024];
		CPXgeterrorstring (env, status, errmsg);
		fatal ("Could not open CPLEX environment. Error: %s",errmsg);
		goto TERMINATE;
	}

	lp = CPXcreateprob (env, &status, "lpex1");

	if (lp == NULL) {
		fatal("Failed to create LP.");
		goto TERMINATE;
	}

	time1 = time(NULL);
	status = populatebynonzero (env, lp, m, n);
	debug2("timer: populating lp took %u",(uint16_t)(time(NULL)-time1));
	debug2("returned from populate %d", status);
	//sprintf(filename,"/home/seren/AUCSCHED2/logs/instance.lp");
	//debug2("lp file: %s",filename);
	time1 = time(NULL);
	//CPXwriteprob (env, lp, filename, NULL);
	//debug2("timer: writing lp took %u",(uint16_t)(time(NULL)-time1));

	if ( status ) {
		fatal("Failed to populate problem.");
		goto TERMINATE;
	}		
	status = CPXsetintparam(env, CPX_PARAM_PARALLELMODE, CPX_PARALLEL_OPPORTUNISTIC);
	
	status = CPXsetdblparam(env, CPX_PARAM_TILIM, timeout);
	debug2("time limit set to %d", timeout);
	if ( status ) {
		fatal("Time limit problem.");
	}

	status = CPXsetintparam(env, CPX_PARAM_THREADS, 12);
	debug2("threads set to %d", 12);
	if ( status ) {
		fatal("thread setting problem.");
	}

	time1 = time(NULL);

	if (bidCtr == 0) {
		info("scheduling at %u no bids created.", time1);
		goto TERMINATE;
	}

	info("scheduling at %u with %d jobs, %d bids",
	        time1, windowSize, bidCtr); 
	status = CPXmipopt (env, lp);
	info("scheduling: solving ip took %u",(uint16_t)(time(NULL)-time1));

	info("scheduling, status: %d - after mipopt", status);
	if (status == CPXERR_NO_SOLN) {
	        info("scheduling: no solution exists. Probably window size error. Reducing window size, status: %d", status);
	        half = true;
	}

	status = CPXgetstat (env, lp);
	info("scheduling, status: %d - after getstat", status);
	
	if ( !status ) {
		info("scheduling: error in status: %d.",status);
		half = true;
		goto TERMINATE;
	}
	
	status2 = CPXgetobjval (env, lp, &objval); 
	if ((status == CPXMIP_TIME_LIM_INFEAS) || 
		((status == CPXMIP_TIME_LIM_FEAS) && (objval < 0.1)) ) {
		info("scheduling: time limit hit, reducing window size by half, status: %d.",status);
	        //sprintf(filename,"/home/seren/AUCSCHED2/logs/error.%d.lp",time1);
	        //debug2("lp file: %s",filename);
	        //CPXwriteprob (env, lp, filename, NULL);	
		half = true;
		goto TERMINATE;
	} 
	
/*
	if ( status ) {
		info("scheduling: failed to optimize LP. status: %d",status);
		goto TERMINATE;
	}
*/	
	info("scheduling, status: %d - after getobjval", status2);
	if ( status2 ) {
		info("scheduling: error in objective value: %d.",status2);
//		fatal("dying, see instance.lp");
	        //sprintf(filename,"/home/seren/AUCSCHED2/logs/error.%d.lp",time1);
	        //debug2("lp file: %s",filename);
	        //CPXwriteprob (env, lp, filename, NULL);	
		half = true;
		goto TERMINATE;
	}
	
	debug2("objective value: %.2f",objval);
	if ( (objval < 0.01) && ((int)(time(NULL)-time1) >= timeout) ) {
	        debug("Objective value 0 and time limit hit. Reducing window size.");
		half = true;
	        //sprintf(filename,"/home/seren/AUCSCHED2/logs/error.%d.lp",time1);
	        //debug2("lp file: %s",filename);
	        //CPXwriteprob (env, lp, filename, NULL);	
//	        return 2;
		goto TERMINATE;
	}

	cur_numrows = CPXgetnumrows (env, lp);
	cur_numcols = CPXgetnumcols (env, lp);
	debug2("numrows: %d, numcols: %d",cur_numrows,cur_numcols);
	x = (double *) malloc (cur_numcols * sizeof(double));

	if ( x == NULL ) {
		status = CPXERR_NO_MEMORY;
		fatal ("Could not allocate memory for solution.");
		goto TERMINATE;
	}

	status = CPXgetmipx (env, lp, x, 0, cur_numcols - 1);
	
	if ( status ) {
		fatal ("Failed to get optimal integer x, status: %d", status);
		goto TERMINATE;
	}
	
	log = fopen("/home/seren/AUCSCHED2/logs/log","a+");
	fprintf(log,"size %d, begin %d, mid: %d, end %d, diff1 %d diff2 %d numBids %d filename %s\n",
		n, (int)begin_time, (int)mid_time, 
		(int)time(NULL), (int)(time(NULL)-begin_time),
		(int)(time(NULL) - mid_time), bidCtr, filename);
	fclose(log);
	
        sprintf(filename,"/home/seren/AUCSCHED2/logs/out.%d",mid_time);
	log = fopen(filename,"w");
        for (k = 0; k < cur_numcols; k++) {
                fprintf(log,"x%d: %.2f\n",k,x[k]);
        }
        fclose(log);
        
	
	if (! status) {
 	for (k = 0; k < bidCtr; k++) {
		if (x[k] > 0.99) {
			/* j'th bid is selected, which job does it belong to ? */
			j = bids[k].jobIdx;
			dummy = 0;
			sjob_ptr = &job_array[j];
			debug2("cplex allocated job %d, bid %d, x: %.2f gpu count: %d",sjob_ptr->job_id,k,x[k], bids[k].gpu);

			// set jobs gpu to allocated number of gpus
			List job_gres_list = sjob_ptr->job_ptr->gres_list;
			if (job_gres_list != NULL) {
				status = gres_job_gpu_set(job_gres_list, bids[k].gpu);
				if (status)
					fatal("problem setting gpu");
			}

			job_det_ptr = sjob_ptr->job_ptr->details;
			sjob_ptr->node_bitmap = (bitstr_t *) 
				bit_alloc (node_record_count);
			job_det_ptr->req_node_bitmap = (bitstr_t *) 
				bit_alloc (node_record_count);
			job_det_ptr->req_node_layout = (uint16_t *) xmalloc 
				(sizeof(uint16_t) * node_record_count);
			job_det_ptr->req_node_bitmap = (bitstr_t *) bit_alloc
				(node_record_count);
                        debug2("job %d has %d nodes",sjob_ptr->job_id,bids[k].lastNode - bids[k].firstNode + 1);
			for (c = bids[k].firstNode; c < bids[k].lastNode; c++) {
			        if (T[c] == 0)
			                continue;
				i = jobNodeName[c];
				debug3("setting node %d (c: %d) for job %d to %d",i,c, sjob_ptr->job_id, T[c]);
				bit_set (sjob_ptr->node_bitmap, (bitoff_t) (i));
				bit_set (job_det_ptr->req_node_bitmap, (bitoff_t) (i));		
				job_det_ptr->req_node_layout[i] = (uint16_t) (T[c]);
				dummy += T[c];
                                
				//debug3("job %d has allocation in node %d : %.3f (u %d r %d) %u node rem: %d alloc now: %d",sjob_ptr->job_id,i,
				        //(x[bidCtr + jobNodeIdx[c]]) + ceil(x[bidCtr + jobNodeIdx[c] + jobNodeCtr]),
				        //(uint16_t) (x[bidCtr + jobNodeIdx[c]]), (uint16_t) (x[bidCtr + jobNodeCtr + jobNodeIdx[c]]),
					//job_det_ptr->req_node_layout[i],node_array[i].rem_cpus,dummy);
			} 
			sjob_ptr->alloc_total = dummy;
			debug3("set alloc total to %d",dummy);

		} 
	} 
	}
	
TERMINATE:
        debug3("moved to terminate");

	free(intervals);
	debug3("freed intervals");
	free(cumsum);
	debug3("freed cumsum");
	for (i = 0; i < classCtr; i++)
	        free(cArray[i].nodesUsed);
        debug3("freed nodesused");
        free(cArray);
        debug3("freed cArray");
        free(bids);
        debug3("freed bids");
        free(jobNodeName);
        free(jobNodeIdx);
        debug3("freed jobNodeNameIdx");
        
	free_and_null ((char **) &x);
	free_and_null ((char **) &slack);
	free_and_null ((char **) &dj);
	free_and_null ((char **) &pi);

	if (lp != NULL) {
		status2 = CPXfreeprob (env, &lp);
		if (status2) {
			fatal("CPXfreeprob failed, error code %d.", status2);
		}
	}

	if (env != NULL) {
		status2 = CPXcloseCPLEX (&env);
		if (status2) {
			char errmsg[1024];
			fatal("Could not close CPLEX environment.");
			CPXgeterrorstring (env, status2, errmsg);
			fatal("%s", errmsg);
		}
	}     

	debug("returning from solve_allocation");	
	if (half)
	        return 2;
	
	return (status);
}

static void free_and_null (char **ptr)
{
	if ( *ptr != NULL ) {
		free (*ptr);
		*ptr = NULL;
	}
}
